import { Link, NavLink, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import {
  HeartPulse,
  CalendarDays,
  MessagesSquare,
  FileHeart,
  Stethoscope,
  LogOut,
  House,
  UserRound,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const navItems = [
  { to: "/", label: "الرئيسية", icon: House, end: true },
  { to: "/doctors", label: "الأطباء", icon: Stethoscope },
  { to: "/appointments", label: "مواعيدي", icon: CalendarDays },
  { to: "/consultations", label: "استشاراتي", icon: MessagesSquare },
  { to: "/record", label: "سجلي الصحي", icon: FileHeart },
];

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2 shrink-0">
      <span
        className={cn(
          "flex h-9 w-9 items-center justify-center rounded-lg",
          light ? "bg-white/10 text-rose-200" : "bg-primary text-primary-foreground",
        )}
      >
        <HeartPulse className="h-5 w-5" />
      </span>
      <span
        className={cn(
          "text-lg font-bold tracking-tight",
          light ? "text-white" : "text-primary",
        )}
      >
        قلبي
      </span>
    </Link>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { data: myDoctor } = trpc.doctor.myProfile.useQuery(undefined, {
    enabled: !!user,
    retry: false,
  });

  return (
    <div className="min-h-dvh flex flex-col">
      {/* الشريط العلوي */}
      <header
        className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/75"
        style={{ paddingTop: "env(safe-area-inset-top)" }}
      >
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4">
          <Logo />
          <nav className="hidden md:flex items-center gap-1 me-auto">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cn(
                    "rounded-md px-3 py-2 text-sm font-medium transition-colors min-h-11 inline-flex items-center",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
            {myDoctor && (
              <NavLink
                to="/doctor"
                className={({ isActive }) =>
                  cn(
                    "rounded-md px-3 py-2 text-sm font-medium transition-colors min-h-11 inline-flex items-center",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                  )
                }
              >
                لوحة الطبيب
              </NavLink>
            )}
          </nav>
          <div className="ms-auto md:ms-0">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 rounded-full p-1 min-h-11 min-w-11 justify-center hover:bg-secondary transition-colors">
                    <Avatar className="h-8 w-8 border border-border">
                      <AvatarImage src={user.avatar ?? undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary text-sm font-semibold">
                        {user.name?.slice(0, 2) ?? "زائر"}
                      </AvatarFallback>
                    </Avatar>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-semibold truncate">{user.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {user.email}
                    </p>
                  </div>
                  {myDoctor && (
                    <DropdownMenuItem onClick={() => navigate("/doctor")}>
                      <Stethoscope className="h-4 w-4" />
                      لوحة الطبيب
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={() => navigate("/record")}>
                    <UserRound className="h-4 w-4" />
                    ملفي الصحي
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => logout()}
                    className="text-destructive focus:text-destructive"
                  >
                    <LogOut className="h-4 w-4" />
                    تسجيل الخروج
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button size="sm" onClick={() => navigate("/login")}>
                تسجيل الدخول
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* المحتوى */}
      <main className="flex-1 pb-24 md:pb-8">{children}</main>

      {/* شريط تنقل سفلي للجوال */}
      <nav
        className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t bg-background/95 backdrop-blur"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="grid grid-cols-5">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center gap-1 py-2 min-h-14 text-[11px] font-medium transition-colors",
                  isActive ? "text-primary" : "text-muted-foreground",
                )
              }
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
