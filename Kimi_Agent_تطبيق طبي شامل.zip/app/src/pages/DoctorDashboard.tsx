import { useState } from "react";
import { Link } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  MessagesSquare,
  CalendarDays,
  CheckCircle2,
  XCircle,
  LockKeyhole,
  FilePlus2,
  Stethoscope,
} from "lucide-react";
import { appointmentStatus, fmtDateTime, fmtDate, recordCategory } from "@/lib/labels";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function DoctorDashboard() {
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });
  const { data: doctor, isLoading } = trpc.doctor.myProfile.useQuery(undefined, {
    enabled: !!user,
  });

  if (authLoading || !user) return null;
  if (isLoading)
    return (
      <div className="mx-auto max-w-5xl px-4 py-8">
        <Skeleton className="h-40 rounded-xl" />
      </div>
    );

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      {doctor ? <DoctorView doctorId={doctor.id} /> : <ClaimProfile />}
    </div>
  );
}

/* ── ربط الحساب بملف طبيب (عرض تجريبي) ── */
function ClaimProfile() {
  const utils = trpc.useUtils();
  const { data: doctors, isLoading } = trpc.doctor.list.useQuery();
  const claim = trpc.doctor.claimProfile.useMutation({
    onSuccess: () => {
      toast.success("تم ربط حسابك بملف الطبيب");
      utils.doctor.myProfile.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const unclaimed = (doctors ?? []).filter((d) => d.userId == null);

  return (
    <div className="mx-auto max-w-2xl">
      <div className="rounded-xl border bg-card p-6 text-center">
        <Stethoscope className="mx-auto h-10 w-10 text-primary" />
        <h1 className="mt-3 text-xl font-bold">لوحة الطبيب</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          حسابك غير مرتبط بملف طبيب بعد. اختر ملفك من القائمة لإدارة استشاراتك
          ومواعيدك:
        </p>
      </div>
      <div className="mt-4 space-y-3">
        {isLoading ? (
          <Skeleton className="h-24 rounded-xl" />
        ) : (
          unclaimed.map((d) => (
            <div
              key={d.id}
              className="flex items-center justify-between gap-3 rounded-xl border bg-card p-4"
            >
              <div>
                <h3 className="font-semibold">{d.name}</h3>
                <p className="text-sm text-muted-foreground">{d.specialty}</p>
              </div>
              <Button
                className="min-h-11"
                disabled={claim.isPending}
                onClick={() => claim.mutate({ doctorId: d.id })}
              >
                هذا أنا
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ── لوحة الطبيب الفعلية ── */
function DoctorView({ doctorId }: { doctorId: number }) {
  const utils = trpc.useUtils();
  const { data: doctor } = trpc.doctor.myProfile.useQuery();
  const { data: consults, isLoading: cLoading } =
    trpc.consultation.doctorConsultations.useQuery();
  const { data: appts, isLoading: aLoading } =
    trpc.appointment.doctorAppointments.useQuery();

  const toggle = trpc.doctor.toggleOnline.useMutation({
    onSuccess: () => utils.doctor.myProfile.invalidate(),
  });

  const [closing, setClosing] = useState<number | null>(null);
  const [summary, setSummary] = useState("");
  const [recordFor, setRecordFor] = useState<number | null>(null);
  const [recordForm, setRecordForm] = useState<{
    title: string;
    category: "diagnosis" | "lab" | "ecg" | "prescription" | "note";
    content: string;
  }>({
    title: "",
    category: "note",
    content: "",
  });

  const closeMutation = trpc.consultation.close.useMutation({
    onSuccess: () => {
      toast.success("تم إغلاق الاستشارة وحفظ الخلاصة");
      setClosing(null);
      setSummary("");
      utils.consultation.doctorConsultations.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const addRecord = trpc.record.addRecord.useMutation({
    onSuccess: () => {
      toast.success("تمت إضافة السجل إلى ملف المريض");
      setRecordFor(null);
      setRecordForm({ title: "", category: "note", content: "" });
    },
    onError: (e) => toast.error(e.message),
  });

  const apptStatus = trpc.appointment.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الموعد");
      utils.appointment.doctorAppointments.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const open = (consults ?? []).filter((c) => c.status === "open");
  const closed = (consults ?? []).filter((c) => c.status === "closed");

  return (
    <div>
      {/* ترويسة الطبيب */}
      <div className="flex flex-col gap-4 rounded-xl border bg-primary p-5 text-primary-foreground sm:flex-row sm:items-center">
        <div className="flex-1">
          <h1 className="text-xl font-bold">{doctor?.name}</h1>
          <p className="mt-1 text-sm text-white/70">
            {doctor?.title} — {doctor?.specialty}
          </p>
        </div>
        <label className="flex min-h-11 items-center gap-3 rounded-lg bg-white/10 px-4">
          <span className="text-sm font-medium">متاح للاستشارات</span>
          <Switch
            dir="ltr"
            checked={doctor?.isOnline === "yes"}
            onCheckedChange={(v) =>
              toggle.mutate({ doctorId, isOnline: v })
            }
          />
        </label>
      </div>

      {/* إحصاءات */}
      <div className="mt-4 grid grid-cols-3 gap-3">
        <Stat label="استشارات مفتوحة" value={open.length} />
        <Stat label="استشارات مغلقة" value={closed.length} />
        <Stat label="مواعيد قادمة" value={(appts ?? []).filter((a) => a.status !== "cancelled" && new Date(a.scheduledAt) >= new Date()).length} />
      </div>

      <Tabs defaultValue="consults" className="mt-6" dir="rtl">
        <TabsList className="grid w-full grid-cols-2 min-h-11">
          <TabsTrigger value="consults" className="min-h-11">
            الاستشارات
          </TabsTrigger>
          <TabsTrigger value="appts" className="min-h-11">
            المواعيد
          </TabsTrigger>
        </TabsList>

        {/* الاستشارات */}
        <TabsContent value="consults" className="mt-4 space-y-3">
          {cLoading ? (
            <Skeleton className="h-24 rounded-xl" />
          ) : (consults ?? []).length === 0 ? (
            <p className="rounded-xl border border-dashed py-12 text-center text-sm text-muted-foreground">
              لا توجد استشارات واردة بعد
            </p>
          ) : (
            <>
              {open.map((c) => (
                <div key={c.id} className="rounded-xl border bg-card p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <MessagesSquare className="h-4 w-4 text-emerald-600" />
                    <h3 className="font-semibold">{c.subject}</h3>
                    <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700">
                      مفتوحة
                    </span>
                    <span className="ms-auto text-xs text-muted-foreground">
                      {fmtDate(c.createdAt)}
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button asChild size="sm" className="min-h-11">
                      <Link to={`/consultations/${c.id}`}>فتح المحادثة</Link>
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="min-h-11"
                      onClick={() => setRecordFor(c.patientId)}
                    >
                      <FilePlus2 className="h-4 w-4" />
                      إضافة سجل للمريض
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="min-h-11 text-destructive hover:text-destructive"
                      onClick={() => setClosing(c.id)}
                    >
                      <LockKeyhole className="h-4 w-4" />
                      إغلاق بالخلاصة
                    </Button>
                  </div>
                </div>
              ))}
              {closed.map((c) => (
                <Link
                  key={c.id}
                  to={`/consultations/${c.id}`}
                  className="block rounded-xl border bg-card/60 p-4 opacity-75 transition-opacity hover:opacity-100"
                >
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{c.subject}</h3>
                    <span className="rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">
                      مغلقة
                    </span>
                    <span className="ms-auto text-xs text-muted-foreground">
                      {fmtDate(c.createdAt)}
                    </span>
                  </div>
                </Link>
              ))}
            </>
          )}
        </TabsContent>

        {/* المواعيد */}
        <TabsContent value="appts" className="mt-4 space-y-3">
          {aLoading ? (
            <Skeleton className="h-24 rounded-xl" />
          ) : (appts ?? []).length === 0 ? (
            <p className="rounded-xl border border-dashed py-12 text-center text-sm text-muted-foreground">
              لا توجد مواعيد محجوزة
            </p>
          ) : (
            appts!.map((a) => {
              const st = appointmentStatus[a.status];
              return (
                <div key={a.id} className="rounded-xl border bg-card p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <CalendarDays className="h-4 w-4 text-primary" />
                    <span className="font-semibold">{fmtDateTime(a.scheduledAt)}</span>
                    <span
                      className={cn(
                        "rounded-full border px-2 py-0.5 text-xs font-medium",
                        st.cls,
                      )}
                    >
                      {st.label}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {a.type === "online" ? "عن بُعد" : "حضوري"}
                    </span>
                  </div>
                  {a.reason && (
                    <p className="mt-2 text-sm text-muted-foreground">{a.reason}</p>
                  )}
                  {(a.status === "pending" || a.status === "confirmed") && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {a.status === "pending" && (
                        <Button
                          size="sm"
                          className="min-h-11"
                          disabled={apptStatus.isPending}
                          onClick={() =>
                            apptStatus.mutate({ id: a.id, status: "confirmed" })
                          }
                        >
                          <CheckCircle2 className="h-4 w-4" />
                          تأكيد
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        className="min-h-11"
                        disabled={apptStatus.isPending}
                        onClick={() =>
                          apptStatus.mutate({ id: a.id, status: "completed" })
                        }
                      >
                        إتمام
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="min-h-11 text-destructive hover:text-destructive"
                        disabled={apptStatus.isPending}
                        onClick={() =>
                          apptStatus.mutate({ id: a.id, status: "cancelled" })
                        }
                      >
                        <XCircle className="h-4 w-4" />
                        إلغاء
                      </Button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </TabsContent>
      </Tabs>

      {/* إغلاق الاستشارة */}
      <Dialog open={closing !== null} onOpenChange={(o) => !o && setClosing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إغلاق الاستشارة بخلاصة</DialogTitle>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label>خلاصة الطبيب وتوصياته للمريض</Label>
            <Textarea
              rows={5}
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="التشخيص المرجح، التوصيات، متى تراجع العيادة…"
            />
          </div>
          <DialogFooter>
            <Button
              className="min-h-11 w-full sm:w-auto"
              disabled={closeMutation.isPending || summary.trim().length < 3}
              onClick={() =>
                closing !== null &&
                closeMutation.mutate({ id: closing, doctorSummary: summary })
              }
            >
              {closeMutation.isPending ? "جارٍ الإغلاق…" : "إغلاق الاستشارة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* إضافة سجل طبي */}
      <Dialog open={recordFor !== null} onOpenChange={(o) => !o && setRecordFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة سجل طبي للمريض</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>العنوان</Label>
              <Input
                className="min-h-11"
                value={recordForm.title}
                onChange={(e) =>
                  setRecordForm((f) => ({ ...f, title: e.target.value }))
                }
                placeholder="مثال: تشخيص رجفان أذيني"
              />
            </div>
            <div className="space-y-1.5">
              <Label>النوع</Label>
              <Select
                value={recordForm.category}
                onValueChange={(v) =>
                  setRecordForm((f) => ({
                    ...f,
                    category: v as typeof f.category,
                  }))
                }
              >
                <SelectTrigger className="min-h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(recordCategory).map(([k, label]) => (
                    <SelectItem key={k} value={k}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>التفاصيل</Label>
              <Textarea
                rows={4}
                value={recordForm.content}
                onChange={(e) =>
                  setRecordForm((f) => ({ ...f, content: e.target.value }))
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              className="min-h-11 w-full sm:w-auto"
              disabled={
                addRecord.isPending ||
                recordForm.title.trim().length < 2 ||
                !recordForm.content.trim()
              }
              onClick={() =>
                recordFor !== null &&
                addRecord.mutate({ patientId: recordFor, ...recordForm })
              }
            >
              {addRecord.isPending ? "جارٍ الحفظ…" : "حفظ السجل"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border bg-card p-4 text-center">
      <p className="text-2xl font-bold text-primary">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
