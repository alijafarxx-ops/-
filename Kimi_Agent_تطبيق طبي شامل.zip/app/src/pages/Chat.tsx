import { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, SendHorizonal, LockKeyhole } from "lucide-react";
import { fmtTime, fmtDate } from "@/lib/labels";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function Chat() {
  const { id } = useParams<{ id: string }>();
  const consultId = Number(id);
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });
  const utils = trpc.useUtils();
  const [draft, setDraft] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: detail, isLoading } = trpc.consultation.byId.useQuery(
    { id: consultId },
    { enabled: !!user && Number.isFinite(consultId) },
  );

  // تحديث الرسائل كل 5 ثوانٍ لمحاكاة المحادثة الحية
  const { data: msgs } = trpc.consultation.messages.useQuery(
    { consultationId: consultId, afterId: 0 },
    {
      enabled: !!user && !!detail,
      refetchInterval: 5000,
    },
  );

  const sendMutation = trpc.consultation.sendMessage.useMutation({
    onSuccess: () => {
      setDraft("");
      utils.consultation.messages.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs?.length]);

  if (authLoading || !user) return null;

  const isOpen = detail?.consultation.status === "open";
  const isDoctor = detail?.isDoctor ?? false;

  const send = () => {
    const content = draft.trim();
    if (!content) return;
    sendMutation.mutate({ consultationId: consultId, content });
  };

  return (
    <div className="mx-auto flex h-[calc(100dvh-3.5rem-4.5rem)] md:h-[calc(100dvh-3.5rem-2rem)] max-w-3xl flex-col px-4 py-4">
      {/* ترويسة المحادثة */}
      {isLoading ? (
        <Skeleton className="h-14 rounded-xl" />
      ) : detail ? (
        <div className="flex items-center gap-3 rounded-xl border bg-card p-3">
          <Link
            to={isDoctor ? "/doctor" : "/consultations"}
            className="flex min-h-11 min-w-11 items-center justify-center rounded-lg hover:bg-secondary"
            aria-label="رجوع"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-semibold">
              {detail.consultation.subject}
            </h1>
            <p className="text-xs text-muted-foreground">
              {isDoctor ? "محادثة مع المريض" : detail.doctor?.name} ·{" "}
              {fmtDate(detail.consultation.createdAt)}
              {!isOpen && " · استشارة مغلقة"}
            </p>
          </div>
          {detail.doctor?.isOnline === "yes" && !isDoctor && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700">
              <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-500" />
              الطبيب متاح
            </span>
          )}
        </div>
      ) : null}

      {/* الرسائل */}
      <div className="mt-3 flex-1 space-y-3 overflow-y-auto rounded-xl border bg-secondary/40 p-4">
        {msgs?.map((m, i) => {
          const mine =
            (isDoctor && m.senderRole === "doctor") ||
            (!isDoctor && m.senderRole === "patient");
          const showDate =
            i === 0 ||
            new Date(m.createdAt).toDateString() !==
              new Date(msgs[i - 1].createdAt).toDateString();
          return (
            <div key={m.id}>
              {showDate && (
                <p className="my-3 text-center text-xs text-muted-foreground">
                  {fmtDate(m.createdAt)}
                </p>
              )}
              <div className={cn("flex", mine ? "justify-start" : "justify-end")}>
                <div
                  className={cn(
                    "max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
                    mine
                      ? "rounded-es-sm bg-primary text-primary-foreground"
                      : "rounded-ee-sm border bg-card",
                  )}
                >
                  <p className="whitespace-pre-wrap">{m.content}</p>
                  <p
                    className={cn(
                      "mt-1 text-[10px]",
                      mine ? "text-primary-foreground/60" : "text-muted-foreground",
                    )}
                  >
                    {fmtTime(m.createdAt)}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* ملخص الطبيب عند الإغلاق */}
      {!isOpen && detail?.consultation.doctorSummary && (
        <div className="mt-3 rounded-xl border border-sky-200 bg-sky-50 p-4">
          <p className="flex items-center gap-2 text-sm font-semibold text-sky-900">
            <LockKeyhole className="h-4 w-4" />
            خلاصة الطبيب وتوصياته
          </p>
          <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-sky-900/80">
            {detail.consultation.doctorSummary}
          </p>
        </div>
      )}

      {/* صندوق الإرسال */}
      {isOpen ? (
        <div className="mt-3 flex items-end gap-2">
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="اكتب رسالتك…"
            rows={1}
            className="max-h-32 min-h-11 flex-1 resize-none"
          />
          <Button
            onClick={send}
            disabled={!draft.trim() || sendMutation.isPending}
            className="min-h-11 min-w-11"
            aria-label="إرسال"
          >
            <SendHorizonal className="h-5 w-5 -scale-x-100" />
          </Button>
        </div>
      ) : (
        <p className="mt-3 rounded-xl border border-dashed p-3 text-center text-sm text-muted-foreground">
          هذه الاستشارة مغلقة — يمكنك بدء استشارة جديدة من صفحة الأطباء
        </p>
      )}
    </div>
  );
}
