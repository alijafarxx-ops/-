import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { LOGIN_PATH } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Star, CalendarDays, MessagesSquare, Search } from "lucide-react";
import { toast } from "sonner";
import type { Doctor } from "@db/schema";

function DoctorCard({
  doctor,
  onBook,
  onConsult,
}: {
  doctor: Doctor;
  onBook: (d: Doctor) => void;
  onConsult: (d: Doctor) => void;
}) {
  return (
    <article className="rounded-xl border bg-card p-5 flex flex-col">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-semibold text-base">{doctor.name}</h3>
          <p className="mt-0.5 text-sm text-muted-foreground">{doctor.title}</p>
        </div>
        {doctor.isOnline === "yes" ? (
          <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700">
            <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-500" />
            متاح الآن
          </span>
        ) : (
          <span className="shrink-0 rounded-full border px-2 py-0.5 text-xs text-muted-foreground">
            غير متاح
          </span>
        )}
      </div>

      <p className="mt-3 text-sm leading-relaxed text-muted-foreground line-clamp-3">
        {doctor.bio}
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
          {(doctor.rating / 10).toFixed(1)}
        </span>
        <span>{doctor.yearsExperience} سنة خبرة</span>
        <span className="font-semibold text-foreground">
          الاستشارة: {doctor.consultationFee} ر.س
        </span>
      </div>

      {doctor.availableDays && (
        <p className="mt-2 text-xs text-muted-foreground">
          أيام الحضور: {doctor.availableDays}
        </p>
      )}

      <div className="mt-4 grid grid-cols-2 gap-2 pt-2 border-t">
        <Button
          variant="outline"
          className="min-h-11"
          onClick={() => onBook(doctor)}
        >
          <CalendarDays className="h-4 w-4" />
          حجز موعد
        </Button>
        <Button className="min-h-11" onClick={() => onConsult(doctor)}>
          <MessagesSquare className="h-4 w-4" />
          استشارة نصية
        </Button>
      </div>
    </article>
  );
}

export default function Doctors() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const { data: doctors, isLoading } = trpc.doctor.list.useQuery();
  const [query, setQuery] = useState("");

  const [bookingFor, setBookingFor] = useState<Doctor | null>(null);
  const [consultFor, setConsultFor] = useState<Doctor | null>(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("10:00");
  const [apptType, setApptType] = useState<"clinic" | "online">("clinic");
  const [reason, setReason] = useState("");
  const [subject, setSubject] = useState("");
  const [firstMessage, setFirstMessage] = useState("");

  const bookMutation = trpc.appointment.book.useMutation({
    onSuccess: () => {
      toast.success("تم حجز الموعد بنجاح، بانتظار تأكيد العيادة");
      setBookingFor(null);
      setReason("");
      utils.appointment.myAppointments.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const consultMutation = trpc.consultation.start.useMutation({
    onSuccess: (c) => {
      toast.success("تم إنشاء الاستشارة");
      setConsultFor(null);
      setSubject("");
      setFirstMessage("");
      navigate(`/consultations/${c?.id}`);
    },
    onError: (e) => toast.error(e.message),
  });

  const requireAuth = (fn: () => void) => {
    if (!user) {
      navigate(LOGIN_PATH);
      return;
    }
    fn();
  };

  const filtered = (doctors ?? []).filter(
    (d) =>
      !query ||
      d.name.includes(query) ||
      d.specialty.includes(query) ||
      (d.subSpecialty ?? "").includes(query),
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">أطباء القلب</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            اختر طبيبك واحجز موعدًا أو ابدأ استشارة نصية فورية
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم أو التخصص…"
            className="ps-9 min-h-11"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56 rounded-xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <p className="py-16 text-center text-muted-foreground">
          لا توجد نتائج مطابقة لبحثك
        </p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((d) => (
            <DoctorCard
              key={d.id}
              doctor={d}
              onBook={(doc) => requireAuth(() => setBookingFor(doc))}
              onConsult={(doc) => requireAuth(() => setConsultFor(doc))}
            />
          ))}
        </div>
      )}

      {/* حجز موعد */}
      <Dialog open={!!bookingFor} onOpenChange={(o) => !o && setBookingFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حجز موعد — {bookingFor?.name}</DialogTitle>
            <DialogDescription>
              اختر التاريخ والوقت المناسبين، وستؤكد العيادة الموعد.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              if (!bookingFor || !date) return;
              bookMutation.mutate({
                doctorId: bookingFor.id,
                scheduledAt: new Date(`${date}T${time}:00`),
                type: apptType,
                reason: reason || undefined,
              });
            }}
          >
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="date">التاريخ</Label>
                <Input
                  id="date"
                  type="date"
                  required
                  min={new Date().toISOString().slice(0, 10)}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="min-h-11"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="time">الوقت</Label>
                <Input
                  id="time"
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="min-h-11"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>نوع الموعد</Label>
              <Select
                value={apptType}
                onValueChange={(v) => setApptType(v as "clinic" | "online")}
              >
                <SelectTrigger className="min-h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="clinic">حضوري في العيادة</SelectItem>
                  <SelectItem value="online">مرئي عن بُعد</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reason">سبب الزيارة (اختياري)</Label>
              <Textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="مثال: خفقان متكرر وألم خفيف في الصدر…"
                rows={3}
              />
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={bookMutation.isPending || !date}
                className="min-h-11 w-full sm:w-auto"
              >
                {bookMutation.isPending ? "جارٍ الحجز…" : "تأكيد الحجز"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* بدء استشارة */}
      <Dialog open={!!consultFor} onOpenChange={(o) => !o && setConsultFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>استشارة نصية — {consultFor?.name}</DialogTitle>
            <DialogDescription>
              صِف حالتك وسيرد عليك الطبيب نصيًا. الاستشارات النصية ليست للطوارئ؛
              عند ألم صدر شديد اتصل بالإسعاف فورًا.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              if (!consultFor) return;
              consultMutation.mutate({
                doctorId: consultFor.id,
                subject,
                firstMessage,
              });
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="subject">موضوع الاستشارة</Label>
              <Input
                id="subject"
                required
                minLength={3}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="مثال: ارتفاع متقطع في ضربات القلب"
                className="min-h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="firstMessage">رسالتك الأولى</Label>
              <Textarea
                id="firstMessage"
                required
                value={firstMessage}
                onChange={(e) => setFirstMessage(e.target.value)}
                placeholder="اشرح الأعراض، منذ متى بدأت، والأدوية التي تتناولها…"
                rows={5}
              />
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={consultMutation.isPending}
                className="min-h-11 w-full sm:w-auto"
              >
                {consultMutation.isPending ? "جارٍ الإرسال…" : "إرسال الاستشارة"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
