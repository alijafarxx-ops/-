import { Link, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { MessagesSquare, ChevronLeft } from "lucide-react";
import { fmtDate } from "@/lib/labels";
import { cn } from "@/lib/utils";

export default function Consultations() {
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });
  const navigate = useNavigate();
  const { data, isLoading } = trpc.consultation.myConsultations.useQuery(
    undefined,
    { enabled: !!user },
  );

  if (authLoading || !user) return null;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold">استشاراتي النصية</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            محادثاتك مع أطباء القلب
          </p>
        </div>
        <Button onClick={() => navigate("/doctors")} className="min-h-11">
          <MessagesSquare className="h-4 w-4" />
          استشارة جديدة
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-xl" />
          ))}
        </div>
      ) : (data ?? []).length === 0 ? (
        <div className="rounded-xl border border-dashed py-16 text-center">
          <MessagesSquare className="mx-auto h-10 w-10 text-muted-foreground/50" />
          <p className="mt-3 font-medium">لا توجد استشارات بعد</p>
          <p className="mt-1 text-sm text-muted-foreground">
            ابدأ استشارتك النصية الأولى مع طبيب قلب
          </p>
          <Button className="mt-4 min-h-11" onClick={() => navigate("/doctors")}>
            اختيار طبيب
          </Button>
        </div>
      ) : (
        <div className="divide-y rounded-xl border bg-card">
          {data!.map(({ consultation, doctor }) => (
            <Link
              key={consultation.id}
              to={`/consultations/${consultation.id}`}
              className="flex items-center gap-3 p-4 transition-colors hover:bg-secondary/60 min-h-14"
            >
              <span
                className={cn(
                  "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
                  consultation.status === "open"
                    ? "bg-emerald-100 text-emerald-700"
                    : "bg-secondary text-muted-foreground",
                )}
              >
                <MessagesSquare className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="truncate font-semibold">
                    {consultation.subject}
                  </h3>
                  <span
                    className={cn(
                      "shrink-0 rounded-full border px-2 py-0.5 text-[11px] font-medium",
                      consultation.status === "open"
                        ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                        : "bg-secondary text-muted-foreground",
                    )}
                  >
                    {consultation.status === "open" ? "مفتوحة" : "مغلقة"}
                  </span>
                </div>
                <p className="mt-0.5 truncate text-sm text-muted-foreground">
                  {doctor.name} · {fmtDate(consultation.createdAt)}
                </p>
              </div>
              <ChevronLeft className="h-4 w-4 shrink-0 text-muted-foreground" />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
