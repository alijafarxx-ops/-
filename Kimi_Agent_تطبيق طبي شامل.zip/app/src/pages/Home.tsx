import { Link, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import {
  Stethoscope,
  MessagesSquare,
  CalendarDays,
  FileHeart,
  Star,
  ArrowLeft,
  Activity,
  ShieldCheck,
  Clock3,
} from "lucide-react";
import { LOGIN_PATH } from "@/const";

function EcgHero() {
  return (
    <svg
      viewBox="0 0 600 120"
      className="w-full max-w-xl text-rose-300/90"
      fill="none"
      aria-hidden
    >
      <path
        className="ecg-line"
        d="M0 60 H120 L140 60 150 20 165 95 180 60 H240 L255 60 262 40 272 75 282 60 H340 L355 60 365 15 380 100 395 60 H460 L475 60 482 45 492 70 502 60 H600"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  );
}

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data: doctors } = trpc.doctor.list.useQuery();
  const onlineCount = doctors?.filter((d) => d.isOnline === "yes").length ?? 0;

  return (
    <div>
      {/* القسم الافتتاحي — عنابي */}
      <section className="bg-primary text-primary-foreground">
        <div className="mx-auto max-w-6xl px-4 py-14 md:py-20">
          <div className="max-w-2xl">
            <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/20 px-3 py-1 text-xs text-white/80">
              <span className="pulse-dot inline-block h-2 w-2 rounded-full bg-emerald-400" />
              {onlineCount > 0
                ? `${onlineCount} أطباء متاحون الآن للاستشارة`
                : "عيادة متخصصة في أمراض القلب"}
            </p>
            <h1 className="text-3xl md:text-5xl font-bold leading-snug md:leading-tight">
              قلبك بين أيدٍ
              <span className="text-rose-300"> أمينة</span>
            </h1>
            <p className="mt-4 text-sm md:text-base leading-relaxed text-white/70">
              عيادة قلبي تجمع نخبة استشاريي القلب في مكان واحد: احجز موعدك،
              استشر طبيبك نصيًا، وتابع سجلك الصحي وقياسات قلبك من أي مكان.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button
                size="lg"
                variant="secondary"
                className="min-h-11"
                onClick={() => navigate("/doctors")}
              >
                <Stethoscope className="h-4 w-4" />
                تصفح الأطباء
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="min-h-11 border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
                onClick={() =>
                  navigate(user ? "/consultations" : LOGIN_PATH)
                }
              >
                <MessagesSquare className="h-4 w-4" />
                ابدأ استشارة نصية
              </Button>
            </div>
          </div>
          <div className="mt-10 opacity-90">
            <EcgHero />
          </div>
        </div>
      </section>

      {/* مزايا */}
      <section className="mx-auto max-w-6xl px-4 py-10 md:py-14">
        <div className="grid gap-px overflow-hidden rounded-xl border bg-border sm:grid-cols-3">
          {[
            {
              icon: Clock3,
              title: "استشارة خلال دقائق",
              desc: "تواصل نصي مباشر مع طبيب قلب حقيقي، دون انتظار في العيادة.",
            },
            {
              icon: ShieldCheck,
              title: "خصوصية تامة",
              desc: "بياناتك الصحية محفوظة بأمان ولا يطّلع عليها إلا طبيبك المعالج.",
            },
            {
              icon: Activity,
              title: "متابعة مستمرة",
              desc: "سجّل نبضك وضغطك وأكسجينك وشاركها مع طبيبك في كل استشارة.",
            },
          ].map((f) => (
            <div key={f.title} className="bg-card p-6">
              <f.icon className="h-6 w-6 text-accent" />
              <h3 className="mt-3 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* نخبة الأطباء */}
      <section className="mx-auto max-w-6xl px-4 pb-10">
        <div className="mb-5 flex items-end justify-between">
          <div>
            <h2 className="text-xl md:text-2xl font-bold">استشاريونا</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              نخبة من أطباء القلب في مختلف التخصصات الدقيقة
            </p>
          </div>
          <Link
            to="/doctors"
            className="inline-flex min-h-11 items-center gap-1 text-sm font-medium text-primary hover:underline"
          >
            عرض الكل
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(doctors ?? []).slice(0, 3).map((d) => (
            <Link
              key={d.id}
              to="/doctors"
              className="group rounded-xl border bg-card p-5 transition-colors hover:border-primary/40"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-semibold group-hover:text-primary">
                    {d.name}
                  </h3>
                  <p className="mt-0.5 text-sm text-muted-foreground">
                    {d.specialty}
                  </p>
                </div>
                {d.isOnline === "yes" && (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 border border-emerald-200">
                    <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-500" />
                    متاح
                  </span>
                )}
              </div>
              <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  {(d.rating / 10).toFixed(1)}
                </span>
                <span>{d.yearsExperience} سنة خبرة</span>
                <span className="font-semibold text-foreground">
                  {d.consultationFee} ر.س
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* خطوات سريعة */}
      {user && (
        <section className="mx-auto max-w-6xl px-4 pb-12">
          <div className="grid gap-4 sm:grid-cols-3">
            <Link
              to="/appointments"
              className="flex items-center gap-3 rounded-xl border bg-card p-4 hover:border-primary/40 min-h-11"
            >
              <CalendarDays className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">إدارة مواعيدي</span>
            </Link>
            <Link
              to="/consultations"
              className="flex items-center gap-3 rounded-xl border bg-card p-4 hover:border-primary/40 min-h-11"
            >
              <MessagesSquare className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">استشاراتي النصية</span>
            </Link>
            <Link
              to="/record"
              className="flex items-center gap-3 rounded-xl border bg-card p-4 hover:border-primary/40 min-h-11"
            >
              <FileHeart className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">سجلي الصحي والقياسات</span>
            </Link>
          </div>
        </section>
      )}
    </div>
  );
}
