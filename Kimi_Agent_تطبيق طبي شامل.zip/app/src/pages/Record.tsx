import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  HeartPulse,
  Plus,
  Droplets,
  Wind,
  FileHeart,
  Save,
} from "lucide-react";
import { fmtDate, fmtDateTime, recordCategory } from "@/lib/labels";
import { toast } from "sonner";

export default function Record() {
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });

  if (authLoading || !user) return null;
  return <RecordInner />;
}

function RecordInner() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-2xl font-bold">سجلي الصحي</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        ملفك الصحي، قياسات قلبك، والسجلات التي يضيفها أطباؤك
      </p>
      <Tabs defaultValue="profile" className="mt-6" dir="rtl">
        <TabsList className="grid w-full grid-cols-3 min-h-11">
          <TabsTrigger value="profile" className="min-h-11">الملف الصحي</TabsTrigger>
          <TabsTrigger value="vitals" className="min-h-11">قياسات القلب</TabsTrigger>
          <TabsTrigger value="records" className="min-h-11">السجلات الطبية</TabsTrigger>
        </TabsList>
        <TabsContent value="profile">
          <ProfileTab />
        </TabsContent>
        <TabsContent value="vitals">
          <VitalsTab />
        </TabsContent>
        <TabsContent value="records">
          <RecordsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ── الملف الصحي ── */
function ProfileTab() {
  const utils = trpc.useUtils();
  const { data: profile, isLoading } = trpc.profile.get.useQuery();
  const [form, setForm] = useState<Record<string, string>>({});
  const [loaded, setLoaded] = useState(false);

  const upsert = trpc.profile.upsert.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ ملفك الصحي");
      utils.profile.get.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) return <Skeleton className="mt-4 h-96 rounded-xl" />;

  if (profile && !loaded) {
    setForm({
      phone: profile.phone ?? "",
      birthYear: profile.birthYear?.toString() ?? "",
      gender: profile.gender ?? "",
      bloodType: profile.bloodType ?? "",
      chronicDiseases: profile.chronicDiseases ?? "",
      medications: profile.medications ?? "",
      allergies: profile.allergies ?? "",
      notes: profile.notes ?? "",
    });
    setLoaded(true);
  }

  const set = (k: string) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <form
      className="mt-4 space-y-4 rounded-xl border bg-card p-5"
      onSubmit={(e) => {
        e.preventDefault();
        upsert.mutate({
          phone: form.phone || undefined,
          birthYear: form.birthYear ? Number(form.birthYear) : undefined,
          gender: (form.gender as "male" | "female") || undefined,
          bloodType: form.bloodType || undefined,
          chronicDiseases: form.chronicDiseases || undefined,
          medications: form.medications || undefined,
          allergies: form.allergies || undefined,
          notes: form.notes || undefined,
        });
      }}
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>رقم الجوال</Label>
          <Input
            dir="ltr"
            className="min-h-11 text-right"
            value={form.phone ?? ""}
            onChange={(e) => set("phone")(e.target.value)}
            placeholder="05xxxxxxxx"
          />
        </div>
        <div className="space-y-1.5">
          <Label>سنة الميلاد</Label>
          <Input
            type="number"
            min={1900}
            max={2026}
            className="min-h-11"
            value={form.birthYear ?? ""}
            onChange={(e) => set("birthYear")(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label>الجنس</Label>
          <Select value={form.gender ?? ""} onValueChange={set("gender")}>
            <SelectTrigger className="min-h-11">
              <SelectValue placeholder="اختر" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">ذكر</SelectItem>
              <SelectItem value="female">أنثى</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>فصيلة الدم</Label>
          <Select value={form.bloodType ?? ""} onValueChange={set("bloodType")}>
            <SelectTrigger className="min-h-11">
              <SelectValue placeholder="اختر" />
            </SelectTrigger>
            <SelectContent>
              {["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"].map((b) => (
                <SelectItem key={b} value={b}>
                  {b}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>الأمراض المزمنة</Label>
        <Textarea
          value={form.chronicDiseases ?? ""}
          onChange={(e) => set("chronicDiseases")(e.target.value)}
          placeholder="مثال: سكري نوع ثانٍ، ارتفاع ضغط الدم…"
          rows={2}
        />
      </div>
      <div className="space-y-1.5">
        <Label>الأدوية الحالية</Label>
        <Textarea
          value={form.medications ?? ""}
          onChange={(e) => set("medications")(e.target.value)}
          placeholder="مثال: أسبرين 100 ملغ يوميًا، ميتفورمين…"
          rows={2}
        />
      </div>
      <div className="space-y-1.5">
        <Label>الحساسية</Label>
        <Textarea
          value={form.allergies ?? ""}
          onChange={(e) => set("allergies")(e.target.value)}
          placeholder="حساسية من أدوية أو أغذية…"
          rows={2}
        />
      </div>
      <div className="space-y-1.5">
        <Label>ملاحظات إضافية</Label>
        <Textarea
          value={form.notes ?? ""}
          onChange={(e) => set("notes")(e.target.value)}
          rows={2}
        />
      </div>
      <Button type="submit" disabled={upsert.isPending} className="min-h-11">
        <Save className="h-4 w-4" />
        {upsert.isPending ? "جارٍ الحفظ…" : "حفظ الملف"}
      </Button>
    </form>
  );
}

/* ── قياسات القلب ── */
function VitalsTab() {
  const utils = trpc.useUtils();
  const { data: vitalList, isLoading } = trpc.record.myVitals.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    heartRate: "",
    systolic: "",
    diastolic: "",
    oxygenSaturation: "",
    note: "",
  });

  const addMutation = trpc.record.addVital.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل القياس");
      setOpen(false);
      setForm({
        heartRate: "",
        systolic: "",
        diastolic: "",
        oxygenSaturation: "",
        note: "",
      });
      utils.record.myVitals.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const latest = vitalList?.[0];
  const hrSeries = (vitalList ?? [])
    .slice(0, 20)
    .reverse()
    .map((v) => v.heartRate)
    .filter((x): x is number => x != null);

  return (
    <div className="mt-4 space-y-4">
      {/* آخر قياس */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <VitalCard
          icon={<HeartPulse className="h-5 w-5 text-rose-600" />}
          label="نبض القلب"
          value={latest?.heartRate}
          unit="نبضة/د"
        />
        <VitalCard
          icon={<Droplets className="h-5 w-5 text-sky-600" />}
          label="ضغط الدم"
          value={
            latest?.systolic && latest?.diastolic
              ? `${latest.systolic}/${latest.diastolic}`
              : null
          }
          unit="ملم زئبق"
        />
        <VitalCard
          icon={<Wind className="h-5 w-5 text-teal-600" />}
          label="أكسجين الدم"
          value={latest?.oxygenSaturation}
          unit="%"
        />
        <button
          onClick={() => setOpen(true)}
          className="flex min-h-24 flex-col items-center justify-center gap-2 rounded-xl border border-dashed text-sm font-medium text-primary transition-colors hover:bg-secondary/60"
        >
          <Plus className="h-5 w-5" />
          تسجيل قياس
        </button>
      </div>

      {/* مخطط النبض */}
      {hrSeries.length > 1 && (
        <div className="rounded-xl border bg-card p-4">
          <p className="mb-2 text-sm font-semibold">تطور نبض القلب</p>
          <Sparkline data={hrSeries} />
          <p className="mt-1 text-xs text-muted-foreground">
            آخر {hrSeries.length} قياسات
          </p>
        </div>
      )}

      {/* السجل */}
      <div className="rounded-xl border bg-card">
        <p className="border-b p-4 text-sm font-semibold">القياسات السابقة</p>
        {isLoading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-12 rounded-lg" />
            ))}
          </div>
        ) : (vitalList ?? []).length === 0 ? (
          <p className="p-8 text-center text-sm text-muted-foreground">
            لم تسجّل أي قياس بعد — سجّل أول قياس لنبضك وضغطك
          </p>
        ) : (
          <ul className="divide-y">
            {vitalList!.map((v) => (
              <li
                key={v.id}
                className="flex flex-wrap items-center gap-x-5 gap-y-1 p-4 text-sm"
              >
                {v.heartRate != null && (
                  <span className="inline-flex items-center gap-1">
                    <HeartPulse className="h-4 w-4 text-rose-600" />
                    {v.heartRate} نبضة/د
                  </span>
                )}
                {v.systolic != null && v.diastolic != null && (
                  <span className="inline-flex items-center gap-1">
                    <Droplets className="h-4 w-4 text-sky-600" />
                    {v.systolic}/{v.diastolic}
                  </span>
                )}
                {v.oxygenSaturation != null && (
                  <span className="inline-flex items-center gap-1">
                    <Wind className="h-4 w-4 text-teal-600" />
                    {v.oxygenSaturation}%
                  </span>
                )}
                {v.note && (
                  <span className="text-muted-foreground">{v.note}</span>
                )}
                <span className="ms-auto text-xs text-muted-foreground">
                  {fmtDateTime(v.recordedAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* نموذج إضافة قياس */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تسجيل قياس جديد</DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              addMutation.mutate({
                heartRate: form.heartRate ? Number(form.heartRate) : undefined,
                systolic: form.systolic ? Number(form.systolic) : undefined,
                diastolic: form.diastolic ? Number(form.diastolic) : undefined,
                oxygenSaturation: form.oxygenSaturation
                  ? Number(form.oxygenSaturation)
                  : undefined,
                note: form.note || undefined,
              });
            }}
          >
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>نبض القلب (نبضة/د)</Label>
                <Input
                  type="number"
                  min={20}
                  max={250}
                  className="min-h-11"
                  value={form.heartRate}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, heartRate: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label>أكسجين الدم (%)</Label>
                <Input
                  type="number"
                  min={50}
                  max={100}
                  className="min-h-11"
                  value={form.oxygenSaturation}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, oxygenSaturation: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label>الضغط الانقباضي</Label>
                <Input
                  type="number"
                  min={50}
                  max={300}
                  className="min-h-11"
                  value={form.systolic}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, systolic: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label>الضغط الانبساطي</Label>
                <Input
                  type="number"
                  min={30}
                  max={200}
                  className="min-h-11"
                  value={form.diastolic}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, diastolic: e.target.value }))
                  }
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>ملاحظة (اختياري)</Label>
              <Input
                className="min-h-11"
                value={form.note}
                onChange={(e) =>
                  setForm((f) => ({ ...f, note: e.target.value }))
                }
                placeholder="مثال: بعد صعود الدرج"
              />
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={addMutation.isPending}
                className="min-h-11 w-full sm:w-auto"
              >
                {addMutation.isPending ? "جارٍ الحفظ…" : "حفظ القياس"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function VitalCard({
  icon,
  label,
  value,
  unit,
}: {
  icon: React.ReactNode;
  label: string;
  value: number | string | null | undefined;
  unit: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="flex items-center gap-2">{icon}</div>
      <p className="mt-2 text-xs text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-xl font-bold">
        {value ?? "—"}
        {value != null && (
          <span className="ms-1 text-xs font-normal text-muted-foreground">
            {unit}
          </span>
        )}
      </p>
    </div>
  );
}

function Sparkline({ data }: { data: number[] }) {
  const w = 600;
  const h = 120;
  const min = Math.min(...data) - 5;
  const max = Math.max(...data) + 5;
  const pts = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * (w - 20) + 10;
      const y = h - 10 - ((v - min) / (max - min)) * (h - 20);
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full text-primary">
      <polyline
        points={pts}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      {data.map((v, i) => {
        const x = (i / (data.length - 1)) * (w - 20) + 10;
        const y = h - 10 - ((v - min) / (max - min)) * (h - 20);
        return <circle key={i} cx={x} cy={y} r="3" fill="currentColor" />;
      })}
    </svg>
  );
}

/* ── السجلات الطبية ── */
function RecordsTab() {
  const { data: records, isLoading } = trpc.record.myRecords.useQuery();

  return (
    <div className="mt-4">
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
      ) : (records ?? []).length === 0 ? (
        <div className="rounded-xl border border-dashed py-16 text-center">
          <FileHeart className="mx-auto h-10 w-10 text-muted-foreground/50" />
          <p className="mt-3 font-medium">لا توجد سجلات طبية بعد</p>
          <p className="mt-1 text-sm text-muted-foreground">
            سيضيف طبيبك التشخيصات والوصفات والتقارير هنا بعد استشاراتك
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {records!.map((r) => (
            <article key={r.id} className="rounded-xl border bg-card p-4">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">{r.title}</h3>
                <span className="rounded-full border bg-secondary px-2 py-0.5 text-xs text-muted-foreground">
                  {recordCategory[r.category]}
                </span>
                <span className="ms-auto text-xs text-muted-foreground">
                  {fmtDate(r.createdAt)}
                </span>
              </div>
              <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
                {r.content}
              </p>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
