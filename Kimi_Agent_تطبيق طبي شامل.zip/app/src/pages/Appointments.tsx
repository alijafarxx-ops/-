import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { useNavigate } from "react-router";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CalendarDays, MapPin, MonitorSmartphone, XCircle } from "lucide-react";
import { appointmentStatus, fmtDateTime } from "@/lib/labels";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function Appointments() {
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.appointment.myAppointments.useQuery(
    undefined,
    { enabled: !!user },
  );
  const cancelMutation = trpc.appointment.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("تم إلغاء الموعد");
      utils.appointment.myAppointments.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  if (authLoading || (!user && !authLoading)) {
    return null; // إعادة توجيه تلقائية إلى صفحة الدخول
  }

  const upcoming = (data ?? []).filter(
    (r) =>
      new Date(r.appointment.scheduledAt) >= new Date() &&
      r.appointment.status !== "cancelled",
  );
  const past = (data ?? []).filter((r) => !upcoming.includes(r));

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold">مواعيدي</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            تابع مواعيدك القادمة والسابقة
          </p>
        </div>
        <Button onClick={() => navigate("/doctors")} className="min-h-11">
          <CalendarDays className="h-4 w-4" />
          حجز موعد جديد
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
      ) : (data ?? []).length === 0 ? (
        <div className="rounded-xl border border-dashed py-16 text-center">
          <CalendarDays className="mx-auto h-10 w-10 text-muted-foreground/50" />
          <p className="mt-3 font-medium">لا توجد مواعيد بعد</p>
          <p className="mt-1 text-sm text-muted-foreground">
            احجز أول موعد لك مع أحد استشاريي القلب
          </p>
          <Button className="mt-4 min-h-11" onClick={() => navigate("/doctors")}>
            تصفح الأطباء
          </Button>
        </div>
      ) : (
        <div className="space-y-8">
          {upcoming.length > 0 && (
            <section>
              <h2 className="mb-3 text-sm font-semibold text-muted-foreground">
                القادمة
              </h2>
              <div className="space-y-3">
                {upcoming.map(({ appointment, doctor }) => (
                  <AppointmentRow
                    key={appointment.id}
                    appointment={appointment}
                    doctorName={doctor.name}
                    onCancel={() =>
                      cancelMutation.mutate({
                        id: appointment.id,
                        status: "cancelled",
                      })
                    }
                    cancelling={cancelMutation.isPending}
                  />
                ))}
              </div>
            </section>
          )}
          {past.length > 0 && (
            <section>
              <h2 className="mb-3 text-sm font-semibold text-muted-foreground">
                السابقة
              </h2>
              <div className="space-y-3 opacity-80">
                {past.map(({ appointment, doctor }) => (
                  <AppointmentRow
                    key={appointment.id}
                    appointment={appointment}
                    doctorName={doctor.name}
                  />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}

function AppointmentRow({
  appointment,
  doctorName,
  onCancel,
  cancelling,
}: {
  appointment: {
    id: number;
    scheduledAt: Date;
    type: "clinic" | "online";
    status: "pending" | "confirmed" | "completed" | "cancelled";
    reason: string | null;
  };
  doctorName: string;
  onCancel?: () => void;
  cancelling?: boolean;
}) {
  const st = appointmentStatus[appointment.status];
  return (
    <div className="flex flex-col gap-3 rounded-xl border bg-card p-4 sm:flex-row sm:items-center">
      <div className="flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="font-semibold">{doctorName}</h3>
          <span
            className={cn(
              "rounded-full border px-2 py-0.5 text-xs font-medium",
              st.cls,
            )}
          >
            {st.label}
          </span>
        </div>
        <p className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <CalendarDays className="h-3.5 w-3.5" />
            {fmtDateTime(appointment.scheduledAt)}
          </span>
          <span className="inline-flex items-center gap-1">
            {appointment.type === "online" ? (
              <>
                <MonitorSmartphone className="h-3.5 w-3.5" /> عن بُعد
              </>
            ) : (
              <>
                <MapPin className="h-3.5 w-3.5" /> حضوري
              </>
            )}
          </span>
        </p>
        {appointment.reason && (
          <p className="mt-1 text-sm text-muted-foreground">
            {appointment.reason}
          </p>
        )}
      </div>
      {onCancel && appointment.status === "pending" && (
        <Button
          variant="outline"
          size="sm"
          className="min-h-11 text-destructive hover:text-destructive"
          disabled={cancelling}
          onClick={onCancel}
        >
          <XCircle className="h-4 w-4" />
          إلغاء
        </Button>
      )}
    </div>
  );
}
