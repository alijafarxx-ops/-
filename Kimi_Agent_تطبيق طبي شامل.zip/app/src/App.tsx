import { Routes, Route } from "react-router";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import NotFound from "@/pages/NotFound";
import Doctors from "@/pages/Doctors";
import Appointments from "@/pages/Appointments";
import Consultations from "@/pages/Consultations";
import Chat from "@/pages/Chat";
import Record from "@/pages/Record";
import DoctorDashboard from "@/pages/DoctorDashboard";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/doctors" element={<Doctors />} />
        <Route path="/appointments" element={<Appointments />} />
        <Route path="/consultations" element={<Consultations />} />
        <Route path="/consultations/:id" element={<Chat />} />
        <Route path="/record" element={<Record />} />
        <Route path="/doctor" element={<DoctorDashboard />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  );
}
