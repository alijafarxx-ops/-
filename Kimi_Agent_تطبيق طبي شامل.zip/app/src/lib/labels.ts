export const appointmentStatus: Record<string, { label: string; cls: string }> = {
  pending: { label: "بانتظار التأكيد", cls: "bg-amber-50 text-amber-700 border-amber-200" },
  confirmed: { label: "مؤكد", cls: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  completed: { label: "مكتمل", cls: "bg-sky-50 text-sky-700 border-sky-200" },
  cancelled: { label: "ملغي", cls: "bg-rose-50 text-rose-700 border-rose-200" },
};

export const recordCategory: Record<string, string> = {
  diagnosis: "تشخيص",
  lab: "تحاليل مخبرية",
  ecg: "تخطيط قلب",
  prescription: "وصفة دوائية",
  note: "ملاحظة طبية",
};

export function fmtDate(d: Date | string | null | undefined) {
  if (!d) return "—";
  return new Intl.DateTimeFormat("ar-SA", {
    dateStyle: "medium",
  }).format(new Date(d));
}

export function fmtDateTime(d: Date | string | null | undefined) {
  if (!d) return "—";
  return new Intl.DateTimeFormat("ar-SA", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(d));
}

export function fmtTime(d: Date | string) {
  return new Intl.DateTimeFormat("ar-SA", {
    timeStyle: "short",
  }).format(new Date(d));
}
