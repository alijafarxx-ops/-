import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  varchar,
  text,
  int,
  timestamp,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/* ───────────────────────── ملف المريض ───────────────────────── */

export const patientProfiles = mysqlTable(
  "patient_profiles",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .unique(),
    phone: varchar("phone", { length: 32 }),
    birthYear: int("birthYear"),
    gender: mysqlEnum("gender", ["male", "female"]),
    bloodType: varchar("bloodType", { length: 8 }),
    chronicDiseases: text("chronicDiseases"),
    medications: text("medications"),
    allergies: text("allergies"),
    notes: text("notes"),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (table) => [index("patient_user_idx").on(table.userId)],
);

export type PatientProfile = typeof patientProfiles.$inferSelect;
export type InsertPatientProfile = typeof patientProfiles.$inferInsert;

/* ───────────────────────── الأطباء ───────────────────────── */

export const doctors = mysqlTable("doctors", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  name: varchar("name", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  specialty: varchar("specialty", { length: 255 }).notNull(),
  subSpecialty: varchar("subSpecialty", { length: 255 }),
  bio: text("bio"),
  yearsExperience: int("yearsExperience").notNull().default(5),
  rating: int("rating").notNull().default(45), // ×10 (45 = 4.5)
  consultationFee: int("consultationFee").notNull().default(150), // بالعملة المحلية
  isOnline: mysqlEnum("isOnline", ["yes", "no"]).notNull().default("no"),
  availableDays: varchar("availableDays", { length: 255 }).notNull().default(""),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Doctor = typeof doctors.$inferSelect;
export type InsertDoctor = typeof doctors.$inferInsert;

/* ───────────────────────── المواعيد ───────────────────────── */

export const appointments = mysqlTable(
  "appointments",
  {
    id: serial("id").primaryKey(),
    patientId: bigint("patientId", { mode: "number", unsigned: true }).notNull(),
    doctorId: bigint("doctorId", { mode: "number", unsigned: true }).notNull(),
    scheduledAt: timestamp("scheduledAt").notNull(),
    type: mysqlEnum("type", ["clinic", "online"]).notNull().default("clinic"),
    status: mysqlEnum("status", [
      "pending",
      "confirmed",
      "completed",
      "cancelled",
    ])
      .notNull()
      .default("pending"),
    reason: text("reason"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("appt_patient_idx").on(table.patientId),
    index("appt_doctor_idx").on(table.doctorId),
  ],
);

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;

/* ───────────────────────── الاستشارات النصية ───────────────────────── */

export const consultations = mysqlTable(
  "consultations",
  {
    id: serial("id").primaryKey(),
    patientId: bigint("patientId", { mode: "number", unsigned: true }).notNull(),
    doctorId: bigint("doctorId", { mode: "number", unsigned: true }).notNull(),
    subject: varchar("subject", { length: 255 }).notNull(),
    status: mysqlEnum("status", ["open", "closed"]).notNull().default("open"),
    doctorSummary: text("doctorSummary"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    closedAt: timestamp("closedAt"),
  },
  (table) => [
    index("consult_patient_idx").on(table.patientId),
    index("consult_doctor_idx").on(table.doctorId),
  ],
);

export type Consultation = typeof consultations.$inferSelect;
export type InsertConsultation = typeof consultations.$inferInsert;

export const messages = mysqlTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    consultationId: bigint("consultationId", {
      mode: "number",
      unsigned: true,
    }).notNull(),
    senderId: bigint("senderId", { mode: "number", unsigned: true }).notNull(),
    senderRole: mysqlEnum("senderRole", ["patient", "doctor"]).notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [index("msg_consult_idx").on(table.consultationId)],
);

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/* ───────────────────────── السجل الطبي ───────────────────────── */

export const medicalRecords = mysqlTable(
  "medical_records",
  {
    id: serial("id").primaryKey(),
    patientId: bigint("patientId", { mode: "number", unsigned: true }).notNull(),
    doctorId: bigint("doctorId", { mode: "number", unsigned: true }),
    title: varchar("title", { length: 255 }).notNull(),
    category: mysqlEnum("category", [
      "diagnosis",
      "lab",
      "ecg",
      "prescription",
      "note",
    ])
      .notNull()
      .default("note"),
    content: text("content").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [index("record_patient_idx").on(table.patientId)],
);

export type MedicalRecord = typeof medicalRecords.$inferSelect;
export type InsertMedicalRecord = typeof medicalRecords.$inferInsert;

/* ───────────────────────── قياسات القلب ───────────────────────── */

export const vitals = mysqlTable(
  "vitals",
  {
    id: serial("id").primaryKey(),
    patientId: bigint("patientId", { mode: "number", unsigned: true }).notNull(),
    heartRate: int("heartRate"),
    systolic: int("systolic"),
    diastolic: int("diastolic"),
    oxygenSaturation: int("oxygenSaturation"),
    note: varchar("note", { length: 255 }),
    recordedAt: timestamp("recordedAt").defaultNow().notNull(),
  },
  (table) => [index("vitals_patient_idx").on(table.patientId)],
);

export type Vital = typeof vitals.$inferSelect;
export type InsertVital = typeof vitals.$inferInsert;
