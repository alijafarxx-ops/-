import { getDb } from "../api/queries/connection";
import { doctors } from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  const existing = await db.query.doctors.findMany();
  if (existing.length === 0) {
    await db.insert(doctors).values([
      {
        name: "د. أحمد الحربي",
        title: "استشاري أول أمراض القلب",
        specialty: "أمراض القلب والأوعية الدموية",
        subSpecialty: "قسطرة القلب التداخلية",
        bio: "استشاري قلب بخبرة تتجاوز 18 عامًا في القسطرة العلاجية وزرع الدعامات، زميل الكلية الأمريكية لأمراض القلب.",
        yearsExperience: 18,
        rating: 49,
        consultationFee: 250,
        isOnline: "yes",
        availableDays: "الأحد,الثلاثاء,الخميس",
      },
      {
        name: "د. سارة العتيبي",
        title: "استشارية أمراض قلب الأطفال",
        specialty: "قلب الأطفال",
        subSpecialty: "تشوهات القلب الخلقية",
        bio: "متخصصة في تشخيص وعلاج أمراض القلب الخلقية لدى الأطفال وحديثي الولادة، مع اهتمام خاص بالمتابعة طويلة المدى.",
        yearsExperience: 12,
        rating: 48,
        consultationFee: 200,
        isOnline: "yes",
        availableDays: "الاثنين,الأربعاء",
      },
      {
        name: "د. خالد المطيري",
        title: "استشاري كهربية القلب",
        specialty: "اضطراب نظم القلب",
        subSpecialty: "زراعة منظمات ومزيلات الرجفان",
        bio: "خبير في علاج اضطرابات نظم القلب والرجفان الأذيني وزراعة الأجهزة القلبية، أجرى أكثر من 3000 عملية ناجحة.",
        yearsExperience: 15,
        rating: 47,
        consultationFee: 300,
        isOnline: "no",
        availableDays: "الأحد,الأربعاء",
      },
      {
        name: "د. منى الشهري",
        title: "استشارية قصور القلب",
        specialty: "قصور القلب وزراعة القلب",
        subSpecialty: "أمراض عضلة القلب",
        bio: "متخصصة في إدارة حالات قصور القلب المتقدم وأمراض عضلة القلب، ورئيسة برنامج تأهيل القلب في العيادة.",
        yearsExperience: 14,
        rating: 49,
        consultationFee: 280,
        isOnline: "yes",
        availableDays: "الثلاثاء,الخميس,السبت",
      },
      {
        name: "د. يوسف القحطاني",
        title: "أخصائي أول أمراض القلب",
        specialty: "أمراض القلب العامة",
        subSpecialty: "الوقاية وارتفاع ضغط الدم",
        bio: "أخصائي قلب يركز على الطب الوقائي وإدارة عوامل الخطورة: الضغط والسكري والكوليسترول والتدخين.",
        yearsExperience: 9,
        rating: 46,
        consultationFee: 150,
        isOnline: "yes",
        availableDays: "الأحد,الاثنين,الأربعاء,الخميس",
      },
      {
        name: "د. نورة الدوسري",
        title: "أخصائية تصوير القلب",
        specialty: "تصوير القلب",
        subSpecialty: "الإيكو والرنين المغناطيسي القلبي",
        bio: "متخصصة في تصوير القلب بالموجات فوق الصوتية والرنين المغناطيسي، مع خبرة في اختبارات الجهد القلبية.",
        yearsExperience: 8,
        rating: 45,
        consultationFee: 180,
        isOnline: "no",
        availableDays: "الاثنين,الخميس",
      },
    ]);
  }

  console.log("Done.");
  process.exit(0);
}

seed();
