import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  doctors,
  appointments,
  consultations,
  messages,
  patientProfiles,
  medicalRecords,
  vitals,
} from "@db/schema";
import { eq, and, desc, asc } from "drizzle-orm";

/* ─────────────── الأطباء ─────────────── */

export const doctorRouter = createRouter({
  list: publicQuery.query(async () => {
    return getDb().query.doctors.findMany({ orderBy: desc(doctors.rating) });
  }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const doctor = await getDb().query.doctors.findFirst({
        where: eq(doctors.id, input.id),
      });
      if (!doctor) throw new TRPCError({ code: "NOT_FOUND" });
      return doctor;
    }),

  // الملف الطبيب المرتبط بحساب المستخدم الحالي (إن وُجد)
  myProfile: authedQuery.query(async ({ ctx }) => {
    const doctor = await getDb().query.doctors.findFirst({
      where: eq(doctors.userId, ctx.user.id),
    });
    return doctor ?? null;
  }),

  // ربط حساب المستخدم بملف طبيب غير مرتبط (لأغراض العرض التجريبي)
  claimProfile: authedQuery
    .input(z.object({ doctorId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.doctors.findFirst({
        where: eq(doctors.userId, ctx.user.id),
      });
      if (existing) return existing;
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.id, input.doctorId),
      });
      if (!doctor) throw new TRPCError({ code: "NOT_FOUND" });
      if (doctor.userId)
        throw new TRPCError({
          code: "CONFLICT",
          message: "هذا الملف مرتبط بحساب آخر",
        });
      await db
        .update(doctors)
        .set({ userId: ctx.user.id })
        .where(eq(doctors.id, input.doctorId));
      return db.query.doctors.findFirst({ where: eq(doctors.id, input.doctorId) });
    }),

  toggleOnline: authedQuery
    .input(z.object({ doctorId: z.number(), isOnline: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.id, input.doctorId),
      });
      if (!doctor || doctor.userId !== ctx.user.id)
        throw new TRPCError({ code: "FORBIDDEN" });
      await db
        .update(doctors)
        .set({ isOnline: input.isOnline ? "yes" : "no" })
        .where(eq(doctors.id, input.doctorId));
      return { ok: true };
    }),
});

/* ─────────────── الملف الصحي للمريض ─────────────── */

export const profileRouter = createRouter({
  get: authedQuery.query(async ({ ctx }) => {
    const profile = await getDb().query.patientProfiles.findFirst({
      where: eq(patientProfiles.userId, ctx.user.id),
    });
    return profile ?? null;
  }),

  upsert: authedQuery
    .input(
      z.object({
        phone: z.string().max(32).optional(),
        birthYear: z.number().min(1900).max(2026).optional(),
        gender: z.enum(["male", "female"]).optional(),
        bloodType: z.string().max(8).optional(),
        chronicDiseases: z.string().optional(),
        medications: z.string().optional(),
        allergies: z.string().optional(),
        notes: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .insert(patientProfiles)
        .values({ userId: ctx.user.id, ...input })
        .onDuplicateKeyUpdate({ set: { ...input } });
      return db.query.patientProfiles.findFirst({
        where: eq(patientProfiles.userId, ctx.user.id),
      });
    }),
});

/* ─────────────── المواعيد ─────────────── */

export const appointmentRouter = createRouter({
  // مواعيد المريض الحالي
  myAppointments: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db
      .select({ appointment: appointments, doctor: doctors })
      .from(appointments)
      .innerJoin(doctors, eq(appointments.doctorId, doctors.id))
      .where(eq(appointments.patientId, ctx.user.id))
      .orderBy(desc(appointments.scheduledAt));
    return rows;
  }),

  // مواعيد الطبيب (حساب مرتبط بملف طبيب)
  doctorAppointments: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const doctor = await db.query.doctors.findFirst({
      where: eq(doctors.userId, ctx.user.id),
    });
    if (!doctor) return [];
    return db.query.appointments.findMany({
      where: eq(appointments.doctorId, doctor.id),
      orderBy: desc(appointments.scheduledAt),
    });
  }),

  book: authedQuery
    .input(
      z.object({
        doctorId: z.number(),
        scheduledAt: z.date(),
        type: z.enum(["clinic", "online"]).default("clinic"),
        reason: z.string().max(1000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      if (input.scheduledAt < new Date())
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "لا يمكن حجز موعد في الماضي",
        });
      const [{ id }] = await db
        .insert(appointments)
        .values({ patientId: ctx.user.id, ...input })
        .$returningId();
      return db.query.appointments.findFirst({
        where: eq(appointments.id, id),
      });
    }),

  updateStatus: authedQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "completed", "cancelled"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const appt = await db.query.appointments.findFirst({
        where: eq(appointments.id, input.id),
      });
      if (!appt) throw new TRPCError({ code: "NOT_FOUND" });
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.userId, ctx.user.id),
      });
      const isPatient = appt.patientId === ctx.user.id;
      const isDoctor = doctor && appt.doctorId === doctor.id;
      if (!isPatient && !isDoctor) throw new TRPCError({ code: "FORBIDDEN" });
      // المريض يستطيع الإلغاء فقط
      if (isPatient && !isDoctor && input.status !== "cancelled")
        throw new TRPCError({ code: "FORBIDDEN" });
      await db
        .update(appointments)
        .set({ status: input.status })
        .where(eq(appointments.id, input.id));
      return { ok: true };
    }),
});

/* ─────────────── الاستشارات والرسائل ─────────────── */

export const consultationRouter = createRouter({
  start: authedQuery
    .input(
      z.object({
        doctorId: z.number(),
        subject: z.string().min(3).max(255),
        firstMessage: z.string().min(1).max(5000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.id, input.doctorId),
      });
      if (!doctor) throw new TRPCError({ code: "NOT_FOUND" });
      const [{ id }] = await db
        .insert(consultations)
        .values({
          patientId: ctx.user.id,
          doctorId: input.doctorId,
          subject: input.subject,
        })
        .$returningId();
      await db.insert(messages).values({
        consultationId: id,
        senderId: ctx.user.id,
        senderRole: "patient",
        content: input.firstMessage,
      });
      return db.query.consultations.findFirst({
        where: eq(consultations.id, id),
      });
    }),

  // استشارات المريض الحالي
  myConsultations: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select({ consultation: consultations, doctor: doctors })
      .from(consultations)
      .innerJoin(doctors, eq(consultations.doctorId, doctors.id))
      .where(eq(consultations.patientId, ctx.user.id))
      .orderBy(desc(consultations.createdAt));
  }),

  // استشارات الطبيب
  doctorConsultations: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const doctor = await db.query.doctors.findFirst({
      where: eq(doctors.userId, ctx.user.id),
    });
    if (!doctor) return [];
    return db.query.consultations.findMany({
      where: eq(consultations.doctorId, doctor.id),
      orderBy: desc(consultations.createdAt),
    });
  }),

  byId: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const consult = await db.query.consultations.findFirst({
        where: eq(consultations.id, input.id),
      });
      if (!consult) throw new TRPCError({ code: "NOT_FOUND" });
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.id, consult.doctorId),
      });
      const isPatient = consult.patientId === ctx.user.id;
      const isDoctor = doctor?.userId === ctx.user.id;
      if (!isPatient && !isDoctor) throw new TRPCError({ code: "FORBIDDEN" });
      const patientProfile = await db.query.patientProfiles.findFirst({
        where: eq(patientProfiles.userId, consult.patientId),
      });
      return {
        consultation: consult,
        doctor,
        isDoctor,
        patientProfile: isDoctor ? patientProfile : null,
      };
    }),

  messages: authedQuery
    .input(z.object({ consultationId: z.number(), afterId: z.number().default(0) }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const consult = await db.query.consultations.findFirst({
        where: eq(consultations.id, input.consultationId),
      });
      if (!consult) throw new TRPCError({ code: "NOT_FOUND" });
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.id, consult.doctorId),
      });
      if (consult.patientId !== ctx.user.id && doctor?.userId !== ctx.user.id)
        throw new TRPCError({ code: "FORBIDDEN" });
      return db.query.messages.findMany({
        where: eq(messages.consultationId, input.consultationId),
        orderBy: asc(messages.createdAt),
      });
    }),

  sendMessage: authedQuery
    .input(
      z.object({
        consultationId: z.number(),
        content: z.string().min(1).max(5000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const consult = await db.query.consultations.findFirst({
        where: eq(consultations.id, input.consultationId),
      });
      if (!consult) throw new TRPCError({ code: "NOT_FOUND" });
      if (consult.status === "closed")
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "هذه الاستشارة مغلقة",
        });
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.id, consult.doctorId),
      });
      const isPatient = consult.patientId === ctx.user.id;
      const isDoctor = doctor?.userId === ctx.user.id;
      if (!isPatient && !isDoctor) throw new TRPCError({ code: "FORBIDDEN" });
      const [{ id }] = await db
        .insert(messages)
        .values({
          consultationId: input.consultationId,
          senderId: ctx.user.id,
          senderRole: isDoctor && !isPatient ? "doctor" : "patient",
          content: input.content,
        })
        .$returningId();
      return db.query.messages.findFirst({ where: eq(messages.id, id) });
    }),

  close: authedQuery
    .input(
      z.object({
        id: z.number(),
        doctorSummary: z.string().max(5000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.userId, ctx.user.id),
      });
      if (!doctor) throw new TRPCError({ code: "FORBIDDEN" });
      const consult = await db.query.consultations.findFirst({
        where: and(
          eq(consultations.id, input.id),
          eq(consultations.doctorId, doctor.id),
        ),
      });
      if (!consult) throw new TRPCError({ code: "NOT_FOUND" });
      await db
        .update(consultations)
        .set({
          status: "closed",
          closedAt: new Date(),
          doctorSummary: input.doctorSummary ?? null,
        })
        .where(eq(consultations.id, input.id));
      return { ok: true };
    }),
});

/* ─────────────── السجل الطبي والقياسات ─────────────── */

export const recordRouter = createRouter({
  // سجلات المريض الحالي
  myRecords: authedQuery.query(async ({ ctx }) => {
    return getDb().query.medicalRecords.findMany({
      where: eq(medicalRecords.patientId, ctx.user.id),
      orderBy: desc(medicalRecords.createdAt),
    });
  }),

  // الطبيب يضيف سجلًا لمريض عالجه (من خلال استشارة مفتوحة/سابقة)
  addRecord: authedQuery
    .input(
      z.object({
        patientId: z.number(),
        title: z.string().min(2).max(255),
        category: z.enum(["diagnosis", "lab", "ecg", "prescription", "note"]),
        content: z.string().min(1).max(10000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const doctor = await db.query.doctors.findFirst({
        where: eq(doctors.userId, ctx.user.id),
      });
      if (!doctor) throw new TRPCError({ code: "FORBIDDEN" });
      // تحقق أن الطبيب عالج هذا المريض فعلاً
      const link = await db.query.consultations.findFirst({
        where: and(
          eq(consultations.doctorId, doctor.id),
          eq(consultations.patientId, input.patientId),
        ),
      });
      if (!link)
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "لا يمكن إضافة سجل لمريض لم تستشِره",
        });
      const [{ id }] = await db
        .insert(medicalRecords)
        .values({ ...input, doctorId: doctor.id })
        .$returningId();
      return db.query.medicalRecords.findFirst({
        where: eq(medicalRecords.id, id),
      });
    }),

  myVitals: authedQuery.query(async ({ ctx }) => {
    return getDb().query.vitals.findMany({
      where: eq(vitals.patientId, ctx.user.id),
      orderBy: desc(vitals.recordedAt),
    });
  }),

  addVital: authedQuery
    .input(
      z.object({
        heartRate: z.number().min(20).max(250).optional(),
        systolic: z.number().min(50).max(300).optional(),
        diastolic: z.number().min(30).max(200).optional(),
        oxygenSaturation: z.number().min(50).max(100).optional(),
        note: z.string().max(255).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [{ id }] = await getDb()
        .insert(vitals)
        .values({ patientId: ctx.user.id, ...input })
        .$returningId();
      return getDb().query.vitals.findFirst({ where: eq(vitals.id, id) });
    }),
});
