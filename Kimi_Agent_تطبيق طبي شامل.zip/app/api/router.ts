import { authRouter } from "./auth-router";
import {
  appointmentRouter,
  consultationRouter,
  doctorRouter,
  profileRouter,
  recordRouter,
} from "./clinicRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  doctor: doctorRouter,
  profile: profileRouter,
  appointment: appointmentRouter,
  consultation: consultationRouter,
  record: recordRouter,
});

export type AppRouter = typeof appRouter;
